var ball,img1,paddle,img2;

function preload() {
  img1 = loadImage('ball.png');
  img2 = loadImage('paddle.png');
}
function setup() {
  createCanvas(400, 400);
  ball = createSprite(30, 200, 10, 10);
  ball.velocityX = 5;
  ball.velocityY = 2;
  ball.addAnimation('ball.png', img1);
  ball.scale = 0.6;
  
  paddle = createSprite(370, 200, 10, 30);
  paddle.addAnimation('paddle.png', img2);
  paddle.scale = 0.9;
}

function draw() {
  background(205,153,0);
   
  paddle.y = mouseY;
  
  edges = createEdgeSprites();
  
  paddle.collide(edges[2]);
  paddle.collide(edges[3]);
  
  if(ball.bounceOff(edges[0])){
    randomVelocity();
  }
  
  if(ball.bounceOff(edges[2])){
    randomVelocity();
  }
  
  if(ball.bounceOff(edges[3])){
    randomVelocity();
  }

  
  if(ball.bounceOff(paddle)) {
   ball.velocityX = random(-7, -12);
   ball.velocityY = random(-5, 5);
  } 
  
  if(ball.x>500){
    ball.x = 30;
    ball.y = 200;
    randomVelocity();
  }
  
  drawSprites();
  
}

function randomVelocity()
{
  ball.velocityY = random(-5,5);
  ball.velocityX = random(6, 10);
}

